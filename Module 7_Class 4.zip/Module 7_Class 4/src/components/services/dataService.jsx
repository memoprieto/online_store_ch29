let catalog=[
    {
        id:1,
        price: 12.55,
        stock:20,
        title:"Cabbage",
        image:"cabbage.jpg",
        discount:5,
        category:"Veggetable"
    },
    {
        id:2,
        price: 10.55,
        stock:20,
        title:"Carrot",
        image:"carrot.jpg",
        discount:5,
        category:"Veggetable"
    },
    {
        id:3,
        price: 9.56,
        stock:20,
        title:"Banana",
        image:"banana.jpg",
        discount:5,
        category:"Fruit"
    },
    {
        id:4,
        price: 8.55,
        stock:20,
        title:"Eggs",
        image:"eggs.jpg",
        discount:5,
        category:"Fruit"
    },
    {
        id:5,
        price: 7.54,
        stock:20,
        title:"Grape",
        image:"grape.jpg",
        discount:5,
        category:"Fruit"
    },
 ];

class DataService{
    getCatalog(){
        return catalog;
    }
}

export default DataService;